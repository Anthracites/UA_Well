import UIKit
import Foundation
import AVFoundation

class ExerciseView: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate  {
    
    @IBOutlet weak var _collectionView: UICollectionView!
    @IBOutlet weak var header: UIView!
    @IBOutlet weak var viewTitle: UIView!
    @IBOutlet weak var contentView: UIView!
    var buttonLabels: [String] = ["Next", "It helped", "Contact a specialist"]
    @IBOutlet weak var exerciseText: AutoResizingTextView!
    @IBOutlet weak var scrollView: UIView!
    @IBOutlet weak var imageHint: UIImageView!
    @IBOutlet weak var breathingHintWidgetButton: UIButton!
    @IBOutlet weak var hintWidget: UIView!
    var inhaleGif, exhalationGif, pauseImage: UIImage!
    var isHintActive: Bool!
    var LastExercise: Bool!
    var HelpExercisesCount: Int!
    var nextButton, itHelpedButton, contactSpecialistButton, startOverbutton: UIButton!
    var buttons: [UIButton] = []
    var commoButtonBG = UIImage(named: "CommonButtonBG")
    private var audioPlayers: [String: AVAudioPlayer] = [:]
    private var exerciseTextHeightConstraint: NSLayoutConstraint?
    var collectionViewItemsCount: Int!
    var IsQuickHelp: Bool!

    private var stepTimer: Timer?
    private var exerciseTimer: Timer?
    private var layoutAlreadyConfigured = false

    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureExercise()
        configureCollectionView()
        SetupWidget()
        GetImages()
        trackAsCurrentScreen()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Layout is configured here rather than in viewDidLoad: at viewDidLoad
        // time the subview frames are still storyboard placeholders, so the
        // height calculations would run against wrong sizes.
        // The guard inside configureLayout() keeps it to a single run.
        configureLayout()
    }

    
   func configureLayout()
    {
        guard !layoutAlreadyConfigured else { return }
        layoutAlreadyConfigured = true

        guard let castedScrollView = scrollView as? UIScrollView else {
            print("⚠️ scrollView outlet is not a UIScrollView — layout not configured")
            return
        }

        exerciseText.adjustHeight()
        let layoutConfig = LayoutConfigurator.Config(
            parentView: view,
            header: header,
            scrollView: castedScrollView,
            contentView: contentView,
            title: viewTitle,
            isHintActive: isHintActive,
            exerciseText: exerciseText,
            hintWidget: hintWidget,
            collectionView: _collectionView,
            collectionViewItemsCount: collectionViewItemsCount
        )
        exerciseTextHeightConstraint = LayoutConfigurator.configure(using: layoutConfig)
    }
    
    func configureCollectionView()
    {
        ConfigCollectionView()
        _collectionView.register(UINib(nibName: "CustomCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "CustomCollectionViewCell")
        _collectionView.dataSource = self
        _collectionView.delegate = self

    }
    
    func  configureExercise()
    {
        LastExercise = IsLastExercise()
        IsQuickHelp = GetCurrentHelpType()
        GetExerices()
    }
    
    func GetImages()
    {
        pauseImage = imageHint.image
        inhaleGif = UIImage.gifImageWithName("BreathWidget", speed: 1)
        exhalationGif = UIImage.gifImageWithName("BreathWidget_r", speed: 1)
    }
    
    func SetupWidget()
    {
        hintWidget.isHidden = !isHintActive
        if (isHintActive == true)
        {
            let _button = breathingHintWidgetButton
            let _label = TranslationDownloader.shared.CurrentTranslation.commonButtons?.ExerciseSteps[3]
            _button?.setTitle(_label, for: .normal)
            _button!.addTarget(self, action: #selector(OnHintButtonClick), for: .touchUpInside)
        }
        setupHintWidgetLayout()
    }
    
    func GetExerices()
    {
        let i: Int = QuickHelpManager.shared.CurrentExercise // index is used in the current array
        let o: Int = QuickHelpManager.shared.CurrentExersicesArray[i] // index of the current exercise in the array

            let _text = String(TranslationDownloader.shared.CurrentTranslation.Exercises[o].description)
            HelpExercisesCount = Int(QuickHelpManager.shared.CurrentExercise)
            exerciseText.text = _text
        
        isHintActive = ExerciseManager.shared.Exercises[o].Visual_hint
        ExerciseManager.shared.CurrentExercise = ExerciseManager.shared.Exercises[o]
        
        if (isHintActive == true)
        {
            ExerciseManager.shared.CurrentStep = 0
        }
    }
    
    func GetCurrentHelpType() -> Bool
    {
        let _currentHelpType = ExerciseManager.shared.CurrentHelpType
        if _currentHelpType == "QuickHelp"
        {
            viewTitle.isHidden = true
            viewTitle = nil
            return true
        }
        else{
            header = nil
            return false
        }
    }
    
    func ConfigCollectionView()
    {
        if IsQuickHelp == true
        {
            if (LastExercise == true)
            {
                collectionViewItemsCount = buttonLabels.count
            }
            else {
                collectionViewItemsCount = buttonLabels.count - 1
            }
        }
        else
        {
            collectionViewItemsCount = 1
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return collectionViewItemsCount

    }
    
    @objc func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomCollectionViewCell", for: indexPath) as! CustomCollectionViewCell
        let newButoon: UIButton = cell.MenuButton
        let _label = buttonLabels[indexPath.item]

        // newButoon may be a button from a reused cell that still carries a
        // target from an earlier configuration — clear it so a tap can't fire
        // both the old and the new handler.
        newButoon.removeTarget(nil, action: nil, for: .allEvents)

        cell.copyButtonProperties(targetButton: newButoon, isFilledButton: true)
        if buttons.indices.contains(indexPath.item) {
            buttons[indexPath.item] = newButoon
        } else {
            buttons.append(newButoon)
        }
        newButoon.setTitle(_label, for: .normal)
        cell.contentMode = .center
        cell.adjustFontSize(for: newButoon)
        SetUpButton(ButtonIndex: indexPath.item)

        if let backgroundImage = newButoon.backgroundImage(for: .normal) {
            
            // set a fixed height for the button
            NSLayoutConstraint.activate([
                newButoon.heightAnchor.constraint(equalToConstant: 40),
                newButoon.widthAnchor.constraint(equalToConstant: 189),
            ])
        }
        return cell
        
    }
    
    @objc func SetUpButton(ButtonIndex: Int)
    {
        guard buttons.indices.contains(ButtonIndex) else {
            print("⚠️ SetUpButton called for an out-of-range index: \(ButtonIndex)")
            return
        }
        let button = buttons[ButtonIndex]

        if (IsQuickHelp == true)
        {
            
            switch ButtonIndex {
            case 0:
                
                if (LastExercise == false)
                {
                    button.addTarget(self, action: #selector(NextButtonHandler), for: .touchUpInside)
                    button.setTitle(TranslationDownloader.shared.CurrentTranslation.commonButtons?.Next, for: .normal)
                    
                }
                else
                {
                    button.addTarget(self, action: #selector(StartOverButtonHandler), for: .touchUpInside)
                    button.setTitle(TranslationDownloader.shared.CurrentTranslation.commonButtons?.Start_over, for: .normal)
                }
                
            case 1:
                button.addTarget(self, action: #selector(ItHelpedButtonHandler), for: .touchUpInside)
                button.setTitle(TranslationDownloader.shared.CurrentTranslation.commonButtons?.It_helped, for: .normal)
            case 2:
                button.addTarget(self, action: #selector(ContactSpecialistButtonHandler), for: .touchUpInside)
                button.setTitle(TranslationDownloader.shared.CurrentTranslation.commonButtons?.Contact_specialist, for: .normal)
                
            default:
                let okButton = buttons[0]
                okButton.addTarget(self, action: #selector(OkButtonHandler), for: .touchUpInside)
                okButton.setTitle("OK", for: .normal)
            }

        }
        else
        {
            let okButton = buttons[0]
            okButton.addTarget(self, action: #selector(OkButtonHandler), for: .touchUpInside)
            okButton.setTitle("OK", for: .normal)
        }
    }
    
    @objc func NextButtonHandler()
    {
        stopExercise()
        
            let nextIndex = QuickHelpManager.shared.CurrentExercise + 1
            if nextIndex < QuickHelpManager.shared.CurrentExersicesArray.count {
                QuickHelpManager.shared.CurrentExercise = nextIndex
                
                let _name = "ExerciseView"
                let storyboard = UIStoryboard(name: _name, bundle: nil)
                let nextVC = storyboard.instantiateViewController(withIdentifier: _name)
                UIApplication.shared.setRootViewController(nextVC)
            }
    }
    
    @objc func ItHelpedButtonHandler()
    {
        stopExercise()
        
        let _name = "HelpTypesMenu"
        let storyboard = UIStoryboard(name: _name, bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: _name)
        UIApplication.shared.setRootViewController(nextVC)
    }
    
    @objc func OkButtonHandler()
    {
        stopExercise()
        
        guard let _name = ExerciseManager.shared.PreviousViewName else {
            print("⚠️ PreviousViewName is not set — cannot navigate back")
            return
        }
        let storyboard = UIStoryboard(name: _name, bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: _name)
        UIApplication.shared.setRootViewController(nextVC)
    }
    
    @objc func ContactSpecialistButtonHandler()
    {
        stopExercise()
        
        let _name = "AboutUsAndContactUs"
        let storyboard = UIStoryboard(name: _name, bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: _name)
        UIApplication.shared.setRootViewController(nextVC)
        
    }
    
    @objc func StartOverButtonHandler()
    {
        stopExercise()
        QuickHelpManager.shared.CurrentExercise = 0
        
        let _name = "ExerciseView"
        let storyboard = UIStoryboard(name: _name, bundle: nil)
        let nextVC = storyboard.instantiateViewController(withIdentifier: _name)
        UIApplication.shared.setRootViewController(nextVC)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        stepTimer?.invalidate()
        exerciseTimer?.invalidate()
        // The breathing GIF keeps animating on the CPU even when the screen is
        // gone, so it has to be stopped explicitly along with the timers.
        imageHint.stopAnimating()
        ExerciseManager.shared.CurrentStep = 0

    }
    
    
    
    func StartExercise(exercise: Exercise) {

        _ = exercise
        _ = ExerciseManager.shared.CurrentStep
            
        exerciseTimer?.invalidate()
        exerciseTimer = nil
        
        let duration = TimeInterval(exercise.ExerciseDuration ?? 0)
         exerciseTimer = Timer.scheduledTimer(withTimeInterval: duration, repeats: false) { [weak self] _ in
             self?.restartExercise()
         }
        
            startStepTimer()
        updateHintState()
        }
        
    private func startStepTimer() {
        let currentStep = ExerciseManager.shared.CurrentStep
        guard let steps = ExerciseManager.shared.CurrentExercise.Steps,
              steps.indices.contains(currentStep) else {
            print("⚠️ Step \(currentStep) is out of range or Steps are not initialised!")
            return
        }

        let stepDuration = TimeInterval(steps[currentStep].duration)

        // clear prevois timer
        stepTimer?.invalidate()
        stepTimer = nil

        guard isHintActive else {
            print("⏸ Hint is unactived — step's timer is not started!")
            return
        }

        // Без retain cycle
        stepTimer = Timer.scheduledTimer(withTimeInterval: stepDuration, repeats: false) { [weak self] _ in
            self?.nextStep()
        }

        print("✅ The step timer has been started for \(stepDuration) seconds.")
    }

        
    @objc private func nextStep() {
        guard let steps = ExerciseManager.shared.CurrentExercise.Steps,
              !steps.isEmpty else {
            print("⚠️ No steps in the exercise — timer stopped!")
            stopExercise()
            return
        }

        // Go to next step
        ExerciseManager.shared.CurrentStep += 1

        // Bounds check
        if ExerciseManager.shared.CurrentStep >= steps.count {
            ExerciseManager.shared.CurrentStep = 0
            print("🔁 The exercise is complete — starting over.")
        } else {
            print("➡️ Go to step \(ExerciseManager.shared.CurrentStep)")
        }

        // timer's reset
        startStepTimer()

        // hint's refresh
        updateHintState()
    }

    
    @objc private func restartExercise() {
        guard let exercise = ExerciseManager.shared.CurrentExercise else {
            print("⚠️ Exercise not initialized — restart is not possible.")
            return
        }

        // step's reset
        ExerciseManager.shared.CurrentStep = 0
        print("🔁 Exercise's reset  — step reseted")

        // step's timer reset
        startStepTimer()

        // exercise's timer reset
        exerciseTimer?.invalidate()
        exerciseTimer = nil

        let duration = TimeInterval(exercise.ExerciseDuration ?? 0)
        exerciseTimer = Timer.scheduledTimer(withTimeInterval: duration, repeats: false) { [weak self] _ in
            self?.restartExercise()
        }

        print("✅ Exercise timer is  restarted for \(duration) sec")
    }

        
    func stopExercise() {
        stepTimer?.invalidate()
        stepTimer = nil

        exerciseTimer?.invalidate()
        exerciseTimer = nil

        print("🛑 All timers have been stopped and reseted")
    }

        
        // Updating the state of the visual hint
    @objc func updateHintState() {
        print("🎬 Exercise started — updating of hints")

        let soundFileName = "metronome"
        let currentStep = ExerciseManager.shared.CurrentStep

        guard let steps = ExerciseManager.shared.CurrentExercise.Steps,
              steps.indices.contains(currentStep) else {
            print("⚠️ Step \(currentStep) is out of range or Steps are not initialised!")
            imageHint.image = pauseImage
            breathingHintWidgetButton.setTitle("Старт", for: .normal)
            return
        }

        let actionIndex = steps[currentStep].action
        let hintLabels = TranslationDownloader.shared.CurrentTranslation.commonButtons?.ExerciseSteps ?? []

        let (hintImage, buttonLabel): (UIImage, String) = {
            switch actionIndex {
            case 0:
                return (inhaleGif, hintLabels[0] ?? "inhale")
            case 1:
                return (exhalationGif, hintLabels[1] ?? "exhale")
            case 2:
                return (exhalationGif, hintLabels[2] ?? "pause")
            default:
                return (pauseImage, "start")
            }
        }()

        imageHint.image = hintImage
        // A static image (the pause frame) has no animation of its own, but the
        // image view keeps running the previous animated image unless it is
        // stopped, so only animate when the new image actually is animated.
        if hintImage.images == nil {
            imageHint.stopAnimating()
        }
        breathingHintWidgetButton.setTitle(buttonLabel, for: .normal)

        playSound(named: soundFileName)
    }



    
    @objc func OnHintButtonClick()
    {
        StartExercise(exercise: ExerciseManager.shared.CurrentExercise)
        print("Start button pressed!!!!")
    }
    
    @objc func SwichCurrentDay()
    {
        let _currentHelpType = ExerciseManager.shared.CurrentHelpType
        
        switch _currentHelpType {
        case "QuickHelp":
            ""
            
        case "Prevention":
            var d = UserDefaults.standard.integer(forKey: "PreventionCurrentDay")
            d += 1
            UserDefaults.standard.set(d, forKey: "PreventionCurrentDay")
            
        case "LongTimeWork":
            var d = UserDefaults.standard.integer(forKey: "LTWCurrentDay")
            d += 1
            UserDefaults.standard.set(d, forKey: "LTWCurrentDay")
            
        default:
            ""
        }
    }
    
    func playSound(named soundFileName: String) {
        // Reuse an already-loaded player instead of re-reading the file and
        // re-decoding audio on every single exercise step (some exercises have
        // 100+ steps, each previously triggering its own file load).
        if let existingPlayer = audioPlayers[soundFileName] {
            existingPlayer.currentTime = 0
            existingPlayer.play()
            return
        }

        guard let soundURL = Bundle.main.url(forResource: soundFileName, withExtension: "mp3") else {
            print("Error: sound's volume \(soundFileName) not found")
            return
        }

        do {
            let player = try AVAudioPlayer(contentsOf: soundURL)
            player.prepareToPlay()
            audioPlayers[soundFileName] = player
            player.play()
        } catch {
            print("Audio playback error: \(error.localizedDescription)")
        }
    }
    func setupHintWidgetLayout() {
        hintWidget.translatesAutoresizingMaskIntoConstraints = true

        NSLayoutConstraint.activate([
            hintWidget.widthAnchor.constraint(equalToConstant: 300/3),
            hintWidget.heightAnchor.constraint(equalTo: hintWidget.widthAnchor)
        ])

        
        let stackView = UIStackView(arrangedSubviews: [imageHint])
            stackView.axis = .vertical
            stackView.spacing = 12
            stackView.alignment = .center
            stackView.distribution = .fill

            hintWidget.addSubview(stackView)

            stackView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                stackView.topAnchor.constraint(equalTo: hintWidget.topAnchor, constant: 12),
                stackView.bottomAnchor.constraint(equalTo: hintWidget.bottomAnchor, constant: -12),
                stackView.leadingAnchor.constraint(equalTo: hintWidget.leadingAnchor, constant: 16),
                stackView.trailingAnchor.constraint(equalTo: hintWidget.trailingAnchor, constant: -16)
            ])
        
        imageHint.addSubview(breathingHintWidgetButton)

        breathingHintWidgetButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            breathingHintWidgetButton.centerXAnchor.constraint(equalTo: imageHint.centerXAnchor),
            breathingHintWidgetButton.centerYAnchor.constraint(equalTo: imageHint.centerYAnchor),
            breathingHintWidgetButton.widthAnchor.constraint(equalToConstant: 120),
            breathingHintWidgetButton.heightAnchor.constraint(equalToConstant: 50)
        ])
        
        breathingHintWidgetButton.isUserInteractionEnabled = true
        imageHint.isUserInteractionEnabled = true


    }
    
    func IsLastExercise() -> Bool
    {
        let c: Int = QuickHelpManager.shared.CurrentExercise
        let a: Int = QuickHelpManager.shared.CurrentExersicesArray.count - 1
        
        let isLast = (a==c)
        print("Is Last Exercise", isLast)
        
        return isLast
    }

    }
